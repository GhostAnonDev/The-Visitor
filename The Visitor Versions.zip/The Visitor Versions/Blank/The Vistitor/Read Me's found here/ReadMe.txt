Made by Anonymous Dev.
-====================-

After seeing the hastel of the installation process of Wii homebrew, 
I decided to make a script that fixes these issues, while still giving 
the same flexablillity. 


 About Mii
-=========-
I don't want any publicity, so I will not take credit for this code. 
If anyone says they coded it, they are lying. I made this because I was bored.
If this gets attention, I will consider a V2. This one will be a lot better, so
try to get it some attention.


 For the Devs
-============-
The folder structure is simple. In Assets\Contraband is where you put your 
Homebrew apps. In the Index.bat, put the install folder, and the name to 
show up to the user. This only accepts 5. For the WBFS folder under 
Assets\Contracts, it just copies the files/Folders. Their is a dummy 
txt in case no folders or files are added. Take it away if needed. This 
can have as many games as you want. Make sure they are legal copies.

 About this version
-==================-
V 1.0.0

Don't sell, take credit for, or scam this product or the clients. If you
want link this code, it will be on github. Have fun, and don't steal/scam.